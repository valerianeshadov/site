# <center>University-website</center>

## 💻Tech Stacks Used

![HTML](https://img.shields.io/badge/html5%20-%23E34F26.svg?&style=for-the-badge&logo=html5&logoColor=white)
![CSS](https://img.shields.io/badge/css3%20-%231572B6.svg?&style=for-the-badge&logo=css3&logoColor=white)
![JS](https://img.shields.io/badge/javascript%20-%23323330.svg?&style=for-the-badge&logo=javascript&logoColor=%23F7DF1E)

<h1 align="center"> Hacktoberfest 2022 🎉</h1>
<div align="center">
    <b>HACKTOBERFEST2022 REPO</b>
</div>
<p align="center">
<b>MAINTAIN THE COMMUNITY GUIDELINE,FOLLOW THE RULE STRICTLY.</b>
</p>
<hr>

![image](https://user-images.githubusercontent.com/70385488/192114009-0830321a-d227-4a4d-8411-6c03b54d7ce6.png)

Hacktoberfest 2022 is finally here, and we're pretty excited about it. We think it's a great time to encourage, recognise and reward developers in the community who dedicate their time to creating for others.

Hacktoberfest is an annual festival hosted by DigitalOcean that takes place in the month of October to celebrate the open source community. As part of this 31-day celebration, contributors and open source maintainers are encouraged to work on open source projects and win swag to mark the occasion.

#### Tips for Contributors:

- PRs beyond our open issues are welcome but make sure your contributions are meaningful and beneficial to other users otherwise your PR may be closed and marked as ‘invalid’.
- Issues before PRs. If you plan to make a contribution, please make sure there is an issue for it. You can either find an existing issue or open a new issue if none exists.
- You are welcome to make your first contribution to this repo.
<br><br>

## <center><u>Contributors of this repo</u></center>
<br>
<div align="center">
<a href="https://github.com/srijoy-paul/University-website/graphs/contributors">
  <img src="https://contrib.rocks/image?repo=srijoy-paul/University-website" />
</a>
  
</div>
<br><br>

<h1>Happy Coding</h1>
	
<a allign="right" href="https://media4.giphy.com/media/rETpIroGtE99IfbYPU/giphy.gif?"><img src="https://media4.giphy.com/media/rETpIroGtE99IfbYPU/giphy.gif?" alt=" " width="200"></a>	
